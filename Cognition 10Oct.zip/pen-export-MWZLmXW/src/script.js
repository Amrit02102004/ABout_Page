window.addEventListener('scroll', function() {
  var circle = document.querySelector('.circle');
  var scrollPosition = window.scrollY;

  if (scrollPosition === 0) {
    circle.classList.remove('scroll');
  } else {
    circle.classList.add('scroll');
  }
});
